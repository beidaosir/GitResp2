// appConfig.js

//配置API请求的基础路径
export const API_BASE_URL = 'http://localhost:8085';
//是否启用支付宝支付
export const USE_ALIPAY = false;